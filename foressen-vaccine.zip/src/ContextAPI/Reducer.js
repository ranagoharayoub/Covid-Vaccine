export const initialState = {
    canadianApi: [],
    LoadingF: true,
    rapid_Api: [],
    LoadingS: true,
}

export const CANADIAN_API = 'CANADIAN_API'
export const RAPID_API = 'RAPID_API'

const reducer = (state, { type, payload }) => {
    switch (type){

    case CANADIAN_API:
        return { ...state, canadianApi: payload , LoadingF: false}
    case RAPID_API:
        return{...state, rapid_Api: payload, LoadingS: false}
        
    default:
        return state
    }
}

export default reducer