import axios from "axios"
import { useEffect } from "react"
import { useStateValue } from "./ContextApi"
import { CANADIAN_API, RAPID_API } from "./Reducer"

function FetchAPI() {
    const [state, dispatch] = useStateValue()
    useEffect(() => {
       
        const canadianApi =async () =>{
            try {
                const {data:{summary}} = await axios.get('https://api.opencovid.ca/')
                console.log(summary)
                dispatch({
                    type: CANADIAN_API,
                    payload: summary
                })
             } catch (error) {
                 console.log(error)
             }
        }
        canadianApi()

       

            const options = {
            method: 'GET',
            url: 'https://vaccovid-coronavirus-vaccine-and-treatment-tracker.p.rapidapi.com/api/covid-ovid-data/sixmonth/USA',
            headers: {
                'x-rapidapi-key': '83ec61f255msha7b65f8f87dbb13p1073b8jsn22f28570ad40',
                'x-rapidapi-host': 'vaccovid-coronavirus-vaccine-and-treatment-tracker.p.rapidapi.com'
            }
            };
            
            axios.request(options).then(function (response) {
                dispatch({
                    type: RAPID_API,
                    payload: response.data,
                })
                console.log(response.data);
            }).catch(function (error) {
                console.error(error);
            });
        
        
    }, [dispatch])

    
}

export default FetchAPI
