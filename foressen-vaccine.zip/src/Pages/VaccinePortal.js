import React from 'react'
import { useStateValue } from '../ContextAPI/ContextApi'
import './VaccinePortal.css'

function VaccinePortal() {
    const[{rapid_Api, LoadingS}]=useStateValue()
    console.log(rapid_Api,LoadingS)
    return (
        <div className='portal-cont'>
             <div className='cards'>
                <p className='company-name'>BIONTECH/ PFIZER</p>
                <div className='cat'>Category: <p style={{color:'#F88B5A', marginLeft:'10px'}}>RNA Based Vaccine</p></div>
                <div className='discription'>Description: <p style={{color:'#F88B5A', marginLeft:'5px'}}>3 LNP-mRNAs; BNT162</p></div>
             </div>
        </div>
    )
}

export default VaccinePortal
